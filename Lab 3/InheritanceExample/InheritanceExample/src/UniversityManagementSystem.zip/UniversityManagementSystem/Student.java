package UniversityManagementSystem;

import java.util.Date;
import java.util.Random;


public class Student extends Personnel {
    public String dept;
    public String programme;
    public String uniqueID;

    public Student(String name, String address, int birthYear, String dept, String programme){
        super(name, address, birthYear);
        this.dept = dept;
        this.programme = programme;
        uniqueID = generateStudentID();

    }

    public String generateStudentID(){
        Random rand = new Random();
        int randomID  = rand.nextInt(9);
        return dept + birthYear + joiningYear + randomID;

    }

    @Override
    public void displayPersonnelinfo() {
        super.displayPersonnelinfo();
        System.out.println("Unique ID: " + generateStudentID());
    }
}
