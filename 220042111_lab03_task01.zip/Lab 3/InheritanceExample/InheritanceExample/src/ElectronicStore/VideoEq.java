//package ElectronicStore;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//
//public class VideoEq {
//
//
//}
