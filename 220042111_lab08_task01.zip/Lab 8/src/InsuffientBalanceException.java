public class InsuffientBalanceException extends Exception{
    public InsuffientBalanceException(String message) {
        super(message);
    }
}

