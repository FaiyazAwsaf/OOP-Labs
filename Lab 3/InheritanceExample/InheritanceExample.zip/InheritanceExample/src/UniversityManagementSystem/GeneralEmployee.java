package UniversityManagementSystem;

import com.sun.source.tree.ReturnTree;

import java.util.Date;
import java.util.Random;

public class GeneralEmployee extends Personnel{

    int room;
    String designation;

    public GeneralEmployee(String name, String address, int birthYear, int room, String designation) {
        super(name, address, birthYear);
        this.room = room;
        this.designation = designation;
    }

    public int generateGeneralID() {
        Random rand = new Random();
        int low = 5;
        int high = 20;
        int randomID = rand.nextInt(high - low) + low;
        return birthYear + joiningYear + randomID;
    }

    public void displayPersonnelinfo() {
        super.displayPersonnelinfo();
        System.out.println("Unique ID: " + generateGeneralID());
    }
}
