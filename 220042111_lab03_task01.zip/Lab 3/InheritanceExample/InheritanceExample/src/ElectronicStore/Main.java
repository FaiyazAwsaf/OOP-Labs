//package ElectronicStore;
//
//public class Main {
//    public static void main(String [] args) {
//        AudioEq device1 = new AudioEq("Sony", 7700, 2020, 224525356, "8MM");
//
//    }
//
//}
