package UniversityManagementSystem;

import java.util.Date;
import java.util.Random;

public class Faculty extends Personnel {
    public String dept;
    public int room;
    public String designation;

    public Faculty(String name, String address, int birthYear, String dept, String designation, int room) {
        super(name, address, birthYear);
        this.dept = dept;
        this.designation = designation;
        this.room = room;
    }

    public String  generateFacultyID() {
        Random rand = new Random();
        int low = 10;
        int high = 20;
        int randomID = rand.nextInt(high - low) + low;
        return dept + birthYear + joiningYear + randomID;
    }

    public void displayPersonnelinfo() {
        super.displayPersonnelinfo();
        System.out.println("Unique ID: " + generateFacultyID());
    }
}
