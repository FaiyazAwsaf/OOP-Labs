package DarazLite;

public class Books extends Products {
    private String author;
    private String publisherName;
    String genre;


    public Books (String name, double quantity, String description, double basePrice, int discountCode, String author, String publisherName, String genre) {
        super(name, quantity, description, basePrice, discountCode);
        this.author = author;
        this.publisherName = publisherName;
        this.genre = genre;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Author: " + author);
        System.out.println("Publisher: " + publisherName);
        System.out.println("Genre: " + genre);
        System.out.println("Price: " + calculatePrice() + "\n");

    }

    @Override
    public double calculatePrice(String genre) {
        double total = 0;
        super.calculatePrice();
        if(genre == "Classic Literature") {
            total = calculatePrice()*.97;
        }
        else if(genre == "Science Fiction") {
            total = calculatePrice()*.97;
        }

        return total;

    }
}
