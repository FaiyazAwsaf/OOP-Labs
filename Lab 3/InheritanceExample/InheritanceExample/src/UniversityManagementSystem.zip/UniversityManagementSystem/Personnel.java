package UniversityManagementSystem;

import java.time.LocalDate;
import java.util.*;

public class Personnel {
    public String name;
    public String address;
    public int uniqueID;
    public int birthYear;
    public int joiningYear;

    public Personnel(String name, String address, int birthYear) {
        this.name = name;
        this.address = address;
        this.birthYear = birthYear;


    }

    private int calculateAge() {
        return 2024 - birthYear;
    }

    public void displayPersonnelinfo() {
        System.out.println("\nName: " + name);
        System.out.println("Address: " + address);
        //System.out.println("Unique ID: " + uniqueID);
        System.out.println("Age: " + calculateAge());
    }
}




