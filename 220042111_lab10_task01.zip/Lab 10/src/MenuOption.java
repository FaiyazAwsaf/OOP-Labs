public enum MenuOption {
    ADD_NEW_BOOK,
    SEARCH_FOR_BOOK,
    DISPLAY_ALL_BOOKS,
    ADD_RATINGS,
    EXIT
}
