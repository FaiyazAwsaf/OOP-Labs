public class InvalidRateException extends Exception{
    public InvalidRateException(String message){
        super(message);
    }
}
