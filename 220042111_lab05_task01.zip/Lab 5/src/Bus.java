import java.util.Objects;

public class Bus extends GroundVehicle {
    public Bus(String name, double initialSpeed, double initialFuel) {

        super(name, initialSpeed, initialFuel);
    }

}