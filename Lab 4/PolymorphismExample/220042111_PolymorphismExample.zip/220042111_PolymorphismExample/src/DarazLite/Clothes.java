package DarazLite;

public class Clothes {

}
