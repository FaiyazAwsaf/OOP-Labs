package DarazLite;

public abstract class Products {
    private String name;
    double quantity;
    private String description;
    double basePrice;
    int discountCode;

    public Products(String name, double quantity, String description, double basePrice, int discountCode) {
        this.name = name;
        this.quantity = quantity;
        this.description = description;
        this.basePrice = basePrice;
        this.discountCode = discountCode;
    }


     public double calculatePrice() {
        if(discountCode == 1234) {
            return 0.9*basePrice*quantity - 50;
        }
        else
            return 0.9*basePrice*quantity;

     }

    public void displayInfo() {
        System.out.println("Product: " + name);
        System.out.println("Quantity: " + quantity);
        System.out.println("Description: " + description);
        System.out.println("Base Price: " + basePrice + " TK");
    }

    public abstract double calculatePrice(String genre);
}

