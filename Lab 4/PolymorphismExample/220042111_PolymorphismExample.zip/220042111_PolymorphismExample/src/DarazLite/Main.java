package DarazLite;

public class Main {
    public static void main(String[] args) {
        Books B1 = new Books("ABC", 2, "ABC DEF GRF RGRF", 1000, 0, "Faiyaz", "XYZ", "Classic Literature");
        Books B2 = new Books("JSDN", 1, "ABC DEF GRF RGRF", 500,1234,"Faiyaz", "XYZ", "Science Fiction");

//        Purchase purchaseB1 = new Purchase(B1, "1234");

        B1.displayInfo();
        B2.displayInfo();
        B1.calculatePrice("Science Fiction");


    }
}
