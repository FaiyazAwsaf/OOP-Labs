public enum Genre {
    FICTION,
    THRILLER,
    ROMANCE,
    SCIENCE_FICTION,
    HORROR,
    BIOGRAPHY,
    HISTORY,
    Other
};